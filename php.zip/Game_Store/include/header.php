<?php 
// CORD
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST");

// 設定 JSON 格式
header('Content-Type: application/json; charset=utf-8');

?>