<?php 

include('./include/header.php');
include('./include/db.php');
include('./include/function.php');

$account = $_POST['account'];
$password = $_POST['password'];

try {
    // mysqli 執行 SQL
    if ($account & $password) {
        $sql = select_userOne('account');
        $result = mysqli_execute_query($conn, $sql, [$account]);
        if (mysqli_num_rows($result) > 0) {
            $row = mysqli_fetch_assoc($result);
            if (password_verify($password, $row['password'])) {
                return_success('success', '');
            } else {
                return_error(400, $status_msg['accountOrPwd_error'], 0);
            }
        } else {
            return_error(400, $status_msg['accountOrPwd_error'], 1);
        }
    } else {
        return_error(400, $status_msg['accountOrPwd_error'], 2);
    }
} catch (Exception $e) {
    return_error(400, $status_msg['accountOrPwd_error'], $e->getMessage());
}

?>