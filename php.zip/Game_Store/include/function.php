<?php 

$status_msg = [
    'account_exist' => '帳號已存在',
    'email_exist' => '信箱已存在',
    'account_not_exist' => '帳號不存在',
    'email_not_exist' => '信箱不存在',
    'accountOrPwd_error' => '帳號或密碼輸入錯誤',
    'collapse_error' => '欄位不得為空',
    'error' => '發生錯誤'
];

function return_error($status, $message, $e) {
    $arr = [];
    $arr['status'] = $status;
    $arr['message'] = $message;
    $arr['data'] = $e;
    echo json_encode($arr);
    exit();
}

function return_success($status, $data) {
    $arr = [];
    $arr['status'] = $status;
    $arr['data'] = $data;
    echo json_encode($arr);
    exit();
}

/* 
    SQL 相關函式
*/

function select_userOne($Num) {
    $sql = "SELECT `account`, `password` FROM `user_data` ";
    switch ($Num) {
        case 'email':
            $sql .= "WHERE `email` = ?;";
            break;
        case 'account':
            $sql .= "WHERE `account` = ?;";
            break;
    }
    return $sql;
}

?>