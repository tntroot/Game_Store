<?php

include('./include/header.php');
include('./include/db.php');
include('./include/function.php');

// $name = '索羅';
// $email = 'asdas45d@gmail.com';
// $account = 'admin123';
// $password = 'asd';
// $phone = '1234567890';
// $birthday = '1998-01-01';

$name = $_POST['name'];
$email = $_POST['email'];
$account = $_POST['account'];
$password = $_POST['password'];
$phone = $_POST['phone'];
$birthday = $_POST['birthday'];

try {
    // mysqli 執行 SQL
    if ($email & $account & $password) {
        $arr = array('email' => $email, 'account' => $account);

        // 檢查是否有重複
        foreach ($arr as $key => $value) {
            $sql = select_userOne($key);
            $result = mysqli_execute_query($conn, $sql,[$value]);
            if (mysqli_num_rows($result) > 0) {
                if($key == 'email'){
                    return_error(400, $status_msg['email_exist'], $value);
                }else{
                    return_error(400, $status_msg['account_exist'], $value);
                }
            }
        }

        $sql = "INSERT INTO `user_data` (`name`, `email`, `account`, `password`, `phone`, `birthday`) VALUES (?,?, ?, ?, ?, ?);";
        $password = password_hash($password, PASSWORD_DEFAULT);
        $result = mysqli_execute_query($conn, $sql, [$name, $email, $account, $password, $phone, $birthday]);
        if ($result) {
            // 以 JSON 形式回傳
            return_success(200, '');
        }
    }else{
        return_error(400, $status_msg['collapse_error'], null);
    }
} catch (Exception $e) {
    return_error('fail', $status_msg['error'], $e->getMessage());
}
