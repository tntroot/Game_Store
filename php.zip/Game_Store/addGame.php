<?php 

include('./header.php');
include('./db.php');
include('./function.php');

?>